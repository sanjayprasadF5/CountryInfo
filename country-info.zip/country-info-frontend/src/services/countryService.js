import axios from "axios";

const API_BASE = "http://localhost:5000/countries";

export const fetchCountries = () => axios.get(`${API_BASE}`);
export const fetchCountryByCode = (code) => axios.get(`${API_BASE}/${code}`);
export const fetchByRegion = (region) =>
  axios.get(`${API_BASE}/region/${region}`);
export const searchCountries = (params) =>
  axios.get(`${API_BASE}/search`, { params });
