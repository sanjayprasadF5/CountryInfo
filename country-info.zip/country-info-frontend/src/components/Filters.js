import React from "react";

const Filters = ({ onFilterChange }) => {
  const handleRegionChange = (event) => {
    onFilterChange("region", event.target.value);
  };

  const handleTimezoneChange = (event) => {
    onFilterChange("timezone", event.target.value);
  };

  return (
    <div className="filters">
      <select onChange={handleRegionChange} defaultValue="">
        <option value="">Select Region</option>
        <option value="Asia">Asia</option>
        <option value="Europe">Europe</option>
        <option value="Africa">Africa</option>
        <option value="Americas">Americas</option>
        <option value="Oceania">Oceania</option>
      </select>

      <select onChange={handleTimezoneChange} defaultValue="">
        <option value="">Select Timezone</option>
        <option value="UTC+05:30">UTC+05:30</option>
        <option value="UTC+01:00">UTC+01:00</option>
        <option value="UTC-08:00">UTC-08:00</option>
        <option value="UTC+03:00">UTC+03:00</option>
      </select>
    </div>
  );
};

export default Filters;
