import React from "react";

const CountryCard = ({ country }) => {
  const getLocalTime = (timezones) => {
    try {
      const offset = timezones?.[0]?.match(/UTC([+-]\d{2}):?(\d{2})?/);
      if (!offset) return "N/A";

      const date = new Date();
      const hours = parseInt(offset[1]);
      const mins = parseInt(offset[2] || "0");
      date.setUTCHours(date.getUTCHours() + hours, date.getUTCMinutes() + mins);
      return date.toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      });
    } catch {
      return "N/A";
    }
  };

  return (
    <div className="border rounded-xl shadow-md p-4 flex flex-col items-center">
      <img
        src={country.flags?.png}
        alt={country.name?.common}
        className="w-24 h-16 object-cover"
      />
      <h2 className="text-lg font-semibold mt-2">{country.name?.common}</h2>
      <p>{country.region}</p>
      <p className="text-sm text-gray-600">
        Time: {getLocalTime(country.timezones)}
      </p>
    </div>
  );
};

export default CountryCard;
