import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import Filters from "../components/Filters";
import SearchBar from "../components/SearchBar";

const CountryList = () => {
  const [countries, setCountries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filteredCountries, setFilteredCountries] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filters, setFilters] = useState({ region: "", timezone: "" });

  const fetchCountries = async () => {
    try {
      const response = await fetch("http://localhost:3000/countries");
      if (!response.ok) {
        throw new Error("Failed to fetch countries");
      }
      const data = await response.json();
      setCountries(data);
      setFilteredCountries(data); // Initialize with all countries
      setLoading(false);
    } catch (error) {
      console.error("Error fetching countries:", error);
      setLoading(false);
    }
  };

  const handleSearchChange = (searchTerm) => {
    setSearchTerm(searchTerm);
    filterCountries(filters, searchTerm);
  };

  const handleFilterChange = (type, value) => {
    setFilters({ ...filters, [type]: value });
    filterCountries({ ...filters, [type]: value }, searchTerm);
  };

  const filterCountries = (filters, searchTerm) => {
    let filtered = countries;

    if (filters.region) {
      filtered = filtered.filter((country) =>
        country.region.toLowerCase().includes(filters.region.toLowerCase())
      );
    }

    if (filters.timezone) {
      filtered = filtered.filter((country) =>
        country.timezones.some((tz) =>
          tz.toLowerCase().includes(filters.timezone.toLowerCase())
        )
      );
    }

    if (searchTerm) {
      filtered = filtered.filter(
        (country) =>
          country.name.common
            .toLowerCase()
            .includes(searchTerm.toLowerCase()) ||
          (country.capital &&
            country.capital[0].toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    setFilteredCountries(filtered);
  };

  useEffect(() => {
    fetchCountries();
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <h1>Country List</h1>
      <SearchBar onSearchChange={handleSearchChange} />
      <Filters onFilterChange={handleFilterChange} />

      <div className="country-list">
        {filteredCountries.map((country) => (
          <div key={country.cca3} className="country-card">
            <img
              src={country.flags.png}
              alt={`Flag of ${country.name.common}`}
              width={100}
            />
            <h3>{country.name.common}</h3>
            <p>{country.region}</p>
            <Link to={`/country/${country.cca3}`}>View Details</Link>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CountryList;
