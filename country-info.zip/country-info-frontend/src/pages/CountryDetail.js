// src/pages/CountryDetail.js
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom"; // Change useHistory to useNavigate

function CountryDetail() {
  const { code } = useParams(); // Country code from URL
  const [country, setCountry] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const navigate = useNavigate(); // Initialize useNavigate here

  // Fetch country details based on the country code
  useEffect(() => {
    const fetchCountryDetails = async () => {
      setLoading(true);
      try {
        const res = await fetch(`http://localhost:5000/countries/${code}`);
        const data = await res.json();
        setCountry(data);
        setLoading(false);
      } catch (err) {
        setError("Failed to load country details");
        setLoading(false);
      }
    };

    fetchCountryDetails();
  }, [code]);

  if (loading) return <div className="text-center mt-8">Loading...</div>;
  if (error)
    return <div className="text-center text-red-500 mt-8">{error}</div>;

  return (
    <div className="p-8">
      {country && (
        <div className="max-w-4xl mx-auto bg-white p-6 rounded-lg shadow">
          <button
            onClick={() => navigate("/")} // Use navigate instead of history.push
            className="text-blue-500 mb-4"
          >
            &larr; Back to Country List
          </button>
          <div className="flex flex-col sm:flex-row items-center">
            <img
              src={country.flag}
              alt={country.name}
              className="w-1/2 sm:w-1/3 h-auto rounded shadow-md"
            />
            <div className="ml-4 mt-4 sm:mt-0">
              <h1 className="text-3xl font-bold">{country.name}</h1>
              <p className="text-lg text-gray-600">{country.region}</p>
              <p className="text-lg text-gray-600 mt-2">
                Population: {country.population}
              </p>
              <p className="text-lg text-gray-600 mt-2">
                Currency: {country.currency}
              </p>
              <p className="text-lg text-gray-600 mt-2">
                Languages: {country.languages.join(", ")}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default CountryDetail;
