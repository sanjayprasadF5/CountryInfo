const express = require("express");
const router = express.Router();
const {
  fetchAllCountries,
  fetchCountryByCode,
} = require("../services/countriesService");

router.get("/", async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query; // Default to page 1, limit 10
    const countries = await fetchAllCountries();
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const result = countries.slice(startIndex, endIndex); // Paginate the countries

    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message || "Internal server error" });
  }
});

router.get("/:code", async (req, res) => {
  try {
    const data = await fetchCountryByCode(req.params.code);
    res.json(data);
  } catch (err) {
    res.status(404).json({ error: "Country not found" });
  }
});

router.get("/region/:region", async (req, res) => {
  try {
    const countries = await fetchAllCountries();
    const filtered = countries.filter(
      (c) => c.region.toLowerCase() === req.params.region.toLowerCase()
    );
    res.json(filtered);
  } catch (err) {
    res.status(500).json({ error: "Failed to filter countries by region" });
  }
});

router.get("/search", async (req, res) => {
  try {
    const { name, capital, region, timezone } = req.query;
    const countries = await fetchAllCountries();

    const filtered = countries.filter((c) => {
      return (
        (!name || c.name.toLowerCase().includes(name.toLowerCase())) &&
        (!capital || c.capital.toLowerCase().includes(capital.toLowerCase())) &&
        (!region || c.region.toLowerCase() === region.toLowerCase()) &&
        (!timezone || c.timezones.some((tz) => tz.includes(timezone)))
      );
    });

    res.json(filtered);
  } catch (err) {
    res.status(500).json({ error: "Failed to search countries" });
  }
});

module.exports = router;
