const axios = require("axios");
const cache = require("../utils/cache");
const https = require("https");

const agent = new https.Agent({ rejectUnauthorized: false });

const BASE_URL = "https://restcountries.com/v3.1";

async function fetchAllCountries() {
  const cachedData = cache.get("allCountries");
  if (cachedData) return cachedData;

  try {
    const response = await axios.get("https://restcountries.com/v3.1/all", {
      httpsAgent: agent,
    });
    const countries = response.data.map((country) => ({
      name: country.name.common,
      flag: country.flags?.png || "",
      region: country.region,
      capital: country.capital?.[0] || "N/A",
      population: country.population,
      currencies: country.currencies,
      languages: country.languages,
      timezones: country.timezones,
      cca2: country.cca2,
    }));

    cache.set("allCountries", countries);
    return countries;
  } catch (error) {
    console.error("Failed to fetch countries:", error.message);
    throw new Error("Failed to fetch countries");
  }
}

async function fetchCountryByCode(code) {
  const response = await axios.get(`${BASE_URL}/alpha/${code}`, {
    httpsAgent: agent,
  });
  return response.data[0];
}

module.exports = {
  fetchAllCountries,
  fetchCountryByCode,
};
